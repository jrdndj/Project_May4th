﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//adding these for new the inputsystem
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Layouts;

public class DeviceCallback : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        InputSystem.onDeviceChange += (device, change) =>
        {
            var midiDevice = device as Minis.MidiDevice;
            if (midiDevice == null) return;

            Debug.Log(string.Format("{0} ({1}) {2}",
                device.description.product, midiDevice.channel, change));
        };
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}

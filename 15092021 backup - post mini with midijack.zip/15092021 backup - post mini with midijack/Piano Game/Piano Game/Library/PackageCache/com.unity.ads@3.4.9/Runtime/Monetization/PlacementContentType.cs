using System;
namespace UnityEngine.Monetization
{
    public enum PlacementContentType
    {
        ShowAd,
        PromoAd,
        SinkPromo,
        Custom
    }
}

﻿namespace Melanchall.DryWetMidi.Common
{
    internal sealed class ObjectWrapper<TObject>
    {
        #region Properties

        public TObject Object { get; set; }

        #endregion
    }
}

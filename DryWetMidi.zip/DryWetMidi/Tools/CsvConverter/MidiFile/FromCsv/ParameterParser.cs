﻿namespace Melanchall.DryWetMidi.Tools
{
    internal delegate object ParameterParser(string parameter, MidiFileCsvConversionSettings settings);
}

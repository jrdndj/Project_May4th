﻿namespace Melanchall.DryWetMidi.Interaction
{
    internal enum TempoMapLine
    {
        Tempo,
        TimeSignature
    }
}
